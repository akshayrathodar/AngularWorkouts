import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';

import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

import { ReactiveFormsModule } from '@angular/forms';
import { from } from 'rxjs';
import { ErrordisplayComponent } from './signup/errordisplay/errordisplay.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UsermoduleComponent } from './usermodule/usermodule.component';
import { AddfriendsComponent } from './addfriends/addfriends.component';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { SeerequestComponent } from './seerequest/seerequest.component';
import { YourfriendsComponent } from './yourfriends/yourfriends.component';

import { Ng2SearchPipeModule } from 'ng2-search-filter';


@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    LoginComponent,
    HeaderComponent,
    FooterComponent,
    ErrordisplayComponent,
    UsermoduleComponent,
    AddfriendsComponent,
    EditprofileComponent,
    SeerequestComponent,
    YourfriendsComponent,

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    Ng2SearchPipeModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    
  ],
  providers: [
  
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }