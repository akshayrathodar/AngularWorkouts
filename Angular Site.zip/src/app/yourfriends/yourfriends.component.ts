import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-yourfriends',
  templateUrl: './yourfriends.component.html',
  styleUrls: ['./yourfriends.component.css']
})
export class YourfriendsComponent implements OnInit {

  constructor(public cs : CommonService,public router:Router) { }
  public firstname : any;
  public lastname: any;
  public token:any;
  public body : any;
  public data :any;
  public id :any;
  public searchvar : any;
  onKeyUp(event: any) {
    this.searchvar = event.target.value;
  };

  ngOnInit(): void {
    if(!(localStorage.getItem('token')==null && localStorage.getItem('token') == undefined))
    {
      this.token = localStorage.getItem('token');
      this.body = {"token":this.token};
      let returnOutput = this.cs.getFriendList("http://localhost/Nctsocial/src/assets/php/yourfriends/",this.body);

      returnOutput.then((res)=>{
         if(res != null && res != undefined)
         {
            if(res == "nothing"){
              alert("You Do Not Have any Friends Till Now");
            }
            else
            {
            this.data = res;
            this.id = localStorage.getItem('id'); 
            } 
         }
          else{
            alert("Didn't Get Response");
          }
        })
      .catch((error)=>{
        alert("Token No More Avalible");
        //this.router.navigate(['login']);     
      });
    }else
    {
      this.router.navigate(['login']);     
    }
  }

}
