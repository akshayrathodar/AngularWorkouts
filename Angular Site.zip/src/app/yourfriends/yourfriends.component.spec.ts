import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YourfriendsComponent } from './yourfriends.component';

describe('YourfriendsComponent', () => {
  let component: YourfriendsComponent;
  let fixture: ComponentFixture<YourfriendsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YourfriendsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YourfriendsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
