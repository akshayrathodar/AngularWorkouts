import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
import { Router } from '@angular/router'
import { FormBuilder, FormGroup,Validator, Validators } from '@angular/forms';
import {HttpClientModule, HttpClient, HttpRequest, HttpResponse, HttpEventType, HttpHandler, HttpHeaders} from '@angular/common/http';


@Component({
  selector: 'app-usermodule',
  templateUrl: './usermodule.component.html',
  styleUrls: ['./usermodule.component.css']
})
export class UsermoduleComponent implements OnInit {
  selectedFile : File = null;
  previewUrl:any = null;
  imgurl : any = null;
  public fileGet : FormGroup;
  fileData: File = null;
  constructor(public commonservice:CommonService,public router : Router,public builder:FormBuilder,private http: HttpClient) {
      this.fileGet = this.builder.group({
        "file":[null,Validators.required]
      });
   }
   
  
  fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
  }
  
  onSubmit() {
    let token = localStorage.getItem("token");  
    const formData = new FormData();
      formData.append('profileImage', this.fileData);
      formData.append('token',token);
 
      this.http.post('http://localhost/Nctsocial/src/assets/php/profilepicture/', formData, {
        observe: 'events'   
      })
      .subscribe(res => {
        console.log("resof events",res);     
        alert("Image Uploaded Successfully");
        this.ngOnInit();
      }) 
  }
   public firstname : any;
   public lastname: any;
   public email:any;
   public mobile :any;
   public profilepicpath : any;
   public token:any;
   public body : any;

  ngOnInit(): void {
    if(!(localStorage.getItem('token')==null && localStorage.getItem('token') == undefined))
    {
      this.token = localStorage.getItem('token');
      this.body = {"token":this.token};
      let returnOutput = this.commonservice.tokenVerify("http://localhost/Nctsocial/src/assets/php/tokenverifier/",this.body);

      returnOutput.then((res)=>{
         if(res != null && res != undefined)
         {
            this.commonservice.currentid = res.id;
            this.firstname = res.firstname;
            this.lastname = res.lastname;
            this.email = res.email;
            this.mobile = res.mobile;
            this.profilepicpath = res.profilepicture;
            if(this.profilepicpath == "")
            {
              this.profilepicpath = '../../assets/defaultimage/p1.jpeg';
            }
          }
          else{
            alert("Didn't Get Response");
          }
        })
      .catch((error)=>{
        alert("Token No More Avalible");
        this.router.navigate(['login']);     
      });
    }else
    {
      this.router.navigate(['login']);     
    }
    
  }
  logout(){
    this.commonservice.isLoggedIn = false;
    localStorage.removeItem('token');
    this.router.navigate(['login']);
  }
  gotoEdit(){
    this.router.navigate(['editprofile']);
  }
  gotoAddfriends(){
    this.router.navigate(['addfriends']);
  }
  gotoseeFriendRequest(){
    this.router.navigate(['seerequest']);
  }
  gotoFriendList(){
    this.router.navigate(['myfriends']);
  }


}
