import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { FormBuilder, FormGroup,Validators } from '@angular/forms';
import { CommonService } from '../services/common.service';



import { from } from 'rxjs';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public frmLogin : FormGroup;
  public isFormSubmit : boolean = false;

  constructor(public commonSer:CommonService,public formBl : FormBuilder,public router : Router) { 

    this.frmLogin = this.formBl.group({
      'email' : ['',[Validators.required,Validators.minLength(6)]],
      'password' : ['',[Validators.required,Validators.minLength(6)]]
    });

  }

  ngOnInit() {
  

  }

  loginSubmit(){

    this.isFormSubmit = true;

    if(!(this.frmLogin.invalid)){
      let email = this.frmLogin.value.email;
      let password = this.frmLogin.value.password;

      let url = 'http://localhost/Nctsocial/src/assets/php/login/index.php';
      

      let body = {"email":email,"password":password};

      let returnOutput = this.commonSer.loginCall(url,body);

      returnOutput.then((res)=>{
         if(res != null && res != undefined){
              this.commonSer.isLoggedIn = true;
              localStorage.setItem("token",res[0]);
              localStorage.setItem("id",res[1]);
              alert("User Verified , Welcome To Nct Social ");
              this.router.navigate(['user']);     
          }
          else{
            alert("Didn't Get Response");
          }
        })
      .catch((error)=>{
        alert("Username Password are Wrong ");
      });
      
   
  

  }
}


}
