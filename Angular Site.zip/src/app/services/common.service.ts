import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  
  public isLoggedIn : boolean = false;
  public currentid = "";
  public firstname : any;
  public lastname : any;
  public email : any;
  public mobile:any;
  constructor(public httpReq : HttpClient) { 
    
  }

  /////////////////////////
  displayMsg(type : string = '',message : string = '') {
    if(type == 'success'){
      console.log("success");
    }else if(type == 'warning'){
      console.log("warning");
    }else if(type == 'error'){
      console.log("error");
    }
  }
  loginCall(url : string,body : any) : Promise<any>{
    
    let postBody = body;
    let postRe = this.httpReq.post(url,{"data":postBody});

    // postRe.subscribe((response)=>{
    //   console.log(response);
    // });

    return postRe.toPromise()
    .then((res)=>{
      console.log('common service logged');
      if(res=="error"){
        throw Error;
      }
      return res;
    })
    .catch((error)=>{
      console.log(error);
        throw error;
    });
  }


  ////////token
  tokenVerify(url : string,body : any) : Promise<any>{
    
    let postBody = body;
    let postRe = this.httpReq.post(url,{"data":postBody});

    // postRe.subscribe((response)=>{
    //   console.log(response);
    // });

    return postRe.toPromise()
    .then((res)=>{
      console.log('token verify then execute');
      if(res=="nouserfound"){
        throw Error;
      }
      return res;
    })
    .catch((error)=>{
        throw error;
    });
  }

  ////////signup

  signupapiCall(url : string,body : any,options :any = '') : Promise<any>{
    
    let signReq = this.httpReq.post(url,{'data':body});
    return signReq.toPromise()
    .then((res)=>{
      console.log(res);
      console.log('common service logged');
      return res;
    })
    .catch((error)=>{
        throw error;
    });
  }

  ///////get all friends
  getFriendList(url:string,body:any):Promise<any>{
   let friendlistReq = this.httpReq.post(url,{'data':body});
    return friendlistReq.toPromise()
    .then((res)=>{
      console.log(res);
      console.log('common service logged');
      return res;
    })
    .catch((error)=>{
        console.log(error);
        throw error;
    });
  }
  //////// send friend request
  sendFriendRequest(url:string,body:any):Promise<any>{
    let friendlistReq = this.httpReq.post(url,{'data':body});
     return friendlistReq.toPromise()
     .then((res)=>{
       console.log(res);
       console.log('common service from request');
       return res;
     })
     .catch((error)=>{
         console.log(error);
         throw error;
     });
   }
}







