import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { UsermoduleComponent } from './usermodule/usermodule.component'
import { AddfriendsComponent } from './addfriends/addfriends.component';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { SeerequestComponent } from './seerequest/seerequest.component';
import { YourfriendsComponent } from './yourfriends/yourfriends.component';
import { from } from 'rxjs';
const routes: Routes = [
  
  {
    path:'signup',
    component:SignupComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'',
    component:LoginComponent
  },
  {
    path:'user',
    component:UsermoduleComponent
  },
  {
    path:'addfriends',
    component:AddfriendsComponent
  },
  {
    path:'editprofile',
    component:EditprofileComponent
  },
  {
    path:'seerequest',
    component:SeerequestComponent
  },
  {
    path:'myfriends',
    component:YourfriendsComponent
  },
  {
    path:'**',
    component:LoginComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }