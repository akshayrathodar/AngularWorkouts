import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-addfriends',
  templateUrl: './addfriends.component.html',
  styleUrls: ['./addfriends.component.css']
})
export class AddfriendsComponent implements OnInit {

  constructor(public cs : CommonService,public router:Router) { 
    
  }
  public firstname : any;
   public lastname: any;
   public token:any;
   public body : any;
   public data :any;
   public id :any;
  ngOnInit(): void {
    if(!(localStorage.getItem('token')==null && localStorage.getItem('token') == undefined))
    {
      this.token = localStorage.getItem('token');
      this.body = {"token":this.token};
      let returnOutput = this.cs.getFriendList("http://localhost/Nctsocial/src/assets/php/userlist/",this.body);

      returnOutput.then((res)=>{
         if(res != null && res != undefined)
         {
            this.data = res;
            this.id = localStorage.getItem('id'); 
         }
          else{
            alert("Didn't Get Response");
          }
        })
      .catch((error)=>{
        alert("Token No More Avalible");
        //this.router.navigate(['login']);     
      });
    }else
    {
      this.router.navigate(['login']);     
    }
  }

  /////send req
  sendRequest(event){
    let fid = event.target.attributes.id.value;
    let ourid = this.id;
    this.body = {"sender":ourid,"receiver":fid};
    let returnreqOutput = this.cs.getFriendList("http://localhost/Nctsocial/src/assets/php/sendfriendrequest/",this.body);

      returnreqOutput.then((res)=>{
         if(res != null && res != undefined)
         {
            if(res == "1")
            {
              alert("Request Sended Successfully");
        
            }
         }
          else{
            alert("Didn't Get Response");
          }
        })
      .catch((error)=>{
        alert("Failed to send Friend Request");
        //this.router.navigate(['login']);     
      });
    
  }

}
