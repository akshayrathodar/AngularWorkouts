<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$data = json_decode(file_get_contents("php://input"));

$fnm = $data->data->firstname;
$lnm = $data->data->lastname;
$email = $data->data->email;
$mobile = $data->data->mobile;
$pass = $data->data->password;
$decpass = base64_encode($pass);


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nctsocial";



$t = 0;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$found = 0;
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}
//////////////////////////////
$sql = "SELECT email FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if($row['email']===$email)
		{
				$found = 1;
		}
    }
} 
/////////////////////////
if(!($fnm=="" && $lnm=="" && $email==""))
{
	if($found==0)
	{
			$sql = "INSERT INTO users (firstname, lastname, email,mobile,password)
			VALUES ('".$fnm."', '".$lnm."', '".$email."','".$mobile."','".$decpass."')";

			if ($conn->query($sql) === TRUE) {
				$t=1;
				print_r(json_encode($t));    
			} else {
				print_r(json_encode("error"));    
			}
	}
	else{
		print_r(json_encode("useralreadyexist"));
	}
}
$conn->close();




?>

