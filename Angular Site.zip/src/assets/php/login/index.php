<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$data = json_decode(file_get_contents("php://input"));

$email = $data->data->email;
$pass = $data->data->password;
$decpass = base64_encode($pass);


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nctsocial";



$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    echo "db error";
}
$result1 = mysqli_query($conn,"SELECT email,id FROM users WHERE email = '".$email."' AND  password = '".$decpass."'");
$data = array();
if(mysqli_num_rows($result1) > 0 )
{
	while($row = mysqli_fetch_assoc($result1)) {
			$data[] = $row;
	}
	$info = array(base64_encode($data[0]["email"]),$data[0]["id"]);
	print_r(json_encode($info));   
}
else
{
	print_r(json_encode("error"));    
}





$conn->close();




?>

