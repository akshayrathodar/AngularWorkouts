<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$data = json_decode(file_get_contents("php://input"));

$ffid = $data->data->receiver;
$ourid = $data->data->sender;


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nctsocial";




// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$success = 0;
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}
//////////////////////////////
/////////////////////////

$sql = "UPDATE relationship SET status = 2 , actionuserid = '".$ourid."' WHERE senderid= '".$ffid."' AND receiverid = '".$ourid."'";

if ($conn->query($sql) === TRUE) {
		$success = 1; 
		print_r(json_encode($success));    
} else {
		print_r(json_encode($sql));    
}

$conn->close();




?>

