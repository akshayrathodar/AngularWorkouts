<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$data = json_decode(file_get_contents("php://input"));

$fnm = $data->data->firstname;
$lnm = $data->data->lastname;
$email = $data->data->email;
$mobile = $data->data->mobile;
$pass = $data->data->password;
$decpass = base64_encode($pass);
$token = $data->data->token;
$originalmail = base64_decode($token);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nctsocial";





// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$found = 0;
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}
//////////////////////////////

/////////////////////////
if(!($fnm=="" && $lnm=="" && $email=="" && $pass == "" && $mobile=="") )
{
	if($found==0)
	{
			$sql = "UPDATE users SET firstname = '".$fnm."', lastname = '".$lnm."', email = '".$email."',mobile = '".$mobile."',password = '".$decpass."' WHERE email = '".$originalmail."'";
			if ($conn->query($sql) === TRUE) {
				print_r(json_encode("updated"));    
			} else {
				print_r(json_encode("error"));    
			}
	}
	else{
		print_r(json_encode("useralreadyexist"));
	}
}
$conn->close();




?>

