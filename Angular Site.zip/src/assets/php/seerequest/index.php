<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$data = json_decode(file_get_contents("php://input"));

$token = $data->data->token;
$email = base64_decode($token);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nctsocial";
$row = "";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) 
{
    echo "db error";
}
$rid;
$gidsql = "select id from users where email = '".$email."'";
$gidres = mysqli_query($conn,$gidsql);
	while($d = mysqli_fetch_assoc($gidres))
	{
		$rid = $d['id'];
	}


$sql = "SELECT users.id,users.firstname,users.lastname FROM users,relationship WHERE (relationship.status = '1' AND relationship.receiverid = '".$rid."') AND users.id = relationship.senderid";
$result = mysqli_query($conn, $sql);
$data = array(); 
if (mysqli_num_rows($result) > 0) {
	
   while($row = mysqli_fetch_assoc($result)) 
    {   
			$data[] = $row;
	
	}
	print_r(json_encode($data));    
} else {
    print_r(json_encode("nothing"));
}




$conn->close();




?>

