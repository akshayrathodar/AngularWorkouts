<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$data = json_decode(file_get_contents("php://input"));

$token = $data->data->token;
$email = base64_decode($token);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nctsocial";
$row = "";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) 
{
    echo "db error";
}
$sql = "SELECT id,firstname,lastname FROM users WHERE NOT users.email = '".$email."'";
$result = mysqli_query($conn, $sql);
$data = array();
if (mysqli_num_rows($result) > 0) {
   while($row = mysqli_fetch_assoc($result)) {
			$data[] = $row;
		}   
} else {
    echo "nothing";
}
print_r(json_encode($data));    




$conn->close();




?>

