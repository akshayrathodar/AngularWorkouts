<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nctsocial";

$con = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($con->connect_error) 
{
    echo "db error";
}
$postdata = file_get_contents("php://input");
$obj           =  json_decode($postdata);


	$auth=$_POST["token"];
   $email=base64_decode($auth);
	$msg = "";
	$msg_class = "";
	
	    $profileImageName = $auth. $_FILES["profileImage"]["name"];
  
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($profileImageName);
    if($_FILES['profileImage']['size'] > 200000) {
      $msg = "Image size should not be greated than 200Kb";
    }
    // check if file exists
    if(file_exists($target_file)) {
      $msg = "File already exists";
    }
    // Upload image only if no errors
    $img = "../../assets/php/profilepicture/uploads/".$profileImageName;
      if(move_uploaded_file($_FILES["profileImage"]["tmp_name"], $target_file)) {
        $sql = "UPDATE `users` SET `profilepicture`='{$img}' WHERE `email`='{$email}'";
        if(mysqli_query($con,$sql)){
          $msg = $img;
        } else {
          $msg = "There was an error in the database";
        }
      } else {
        $msg = "There was an erro uploading the file";
      }
    
   print_r(json_encode($msg));    


?>
