-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2020 at 07:32 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nctsocial`
--

-- --------------------------------------------------------

--
-- Table structure for table `relationship`
--

CREATE TABLE `relationship` (
  `id` int(11) NOT NULL,
  `senderid` int(255) NOT NULL,
  `receiverid` int(255) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 0,
  `actionuserid` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `relationship`
--

INSERT INTO `relationship` (`id`, `senderid`, `receiverid`, `status`, `actionuserid`) VALUES
(25, 0, 0, 2, 0),
(26, 19, 20, 2, 20),
(27, 19, 21, 2, 21),
(28, 22, 19, 2, 19),
(29, 22, 20, 2, 20),
(30, 22, 21, 1, 22);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profilepicture` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `full_name`, `email`, `mobile`, `password`, `profilepicture`) VALUES
(19, 'akshay', 'rathod', 'akshay rathod', 'ar@gmail.com', '9429076228', 'MTIzNDU2', '../../assets/php/profilepicture/uploads/YXJAZ21haWwuY29tDSC01253.JPG'),
(20, 'rushi', 'rathod', 'rushi rathod', 'rr@gmail.com', '0123012301', 'MTIzNDU2', '../../assets/php/profilepicture/uploads/cnJAZ21haWwuY29tDSC01253.JPG'),
(21, 'madha', 'bhai', 'madha bhai', 'md@gmail.com', '4561230123', 'MTIzNDU2', '../../assets/php/profilepicture/uploads/bWRAZ21haWwuY29tDSC01253.JPG'),
(22, 'raja', 'rama', 'raja rama', 'rm@gmail.com', '7418529630', 'MTIzNDU2', '');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `nctfullname` BEFORE INSERT ON `users` FOR EACH ROW SET new.full_name = CONCAT(new.firstname,' ', new.lastname)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `nctuserdel` AFTER DELETE ON `users` FOR EACH ROW BEGIN
DELETE FROM relationship
    WHERE relationship.senderid = old.id OR relationship.receiverid = old.id;
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `relationship`
--
ALTER TABLE `relationship`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `relationship`
--
ALTER TABLE `relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
