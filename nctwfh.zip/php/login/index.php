<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$data = json_decode(file_get_contents("php://input"));

$email = $data->data->email;
$pass = $data->data->password;
$decpass = base64_encode($pass);


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nctsocial";



$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    echo "db error";
}
$result1 = mysqli_query($conn,"SELECT email FROM users WHERE email = '".$email."' AND  password = '".$decpass."'");

if(mysqli_num_rows($result1) > 0 )
{
		$t = base64_encode($email);   
}
else
{
    $t = "error";
}
print_r(json_encode($t));    




$conn->close();




?>

