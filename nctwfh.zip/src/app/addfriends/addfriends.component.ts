import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addfriends',
  templateUrl: './addfriends.component.html',
  styleUrls: ['./addfriends.component.css']
})
export class AddfriendsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
