import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  
  public isLoggedIn : boolean = false;

  constructor(public httpReq : HttpClient) { 
    
  }

  /////////////////////////
  displayMsg(type : string = '',message : string = '') {
    if(type == 'success'){
      console.log("success");
    }else if(type == 'warning'){
      console.log("warning");
    }else if(type == 'error'){
      console.log("error");
    }
  }
  loginCall(url : string,body : any) : Promise<any>{
    
    let postBody = body;
    let postRe = this.httpReq.post(url,{"data":postBody});

    // postRe.subscribe((response)=>{
    //   console.log(response);
    // });

    return postRe.toPromise()
    .then((res)=>{
      console.log('common service logged');
      if(res=="error"){
        throw Error;
      }
      return res;
    })
    .catch((error)=>{
        throw error;
    });
  }


  ////////token
  tokenVerify(url : string,body : any) : Promise<any>{
    
    let postBody = body;
    let postRe = this.httpReq.post(url,{"data":postBody});

    // postRe.subscribe((response)=>{
    //   console.log(response);
    // });

    return postRe.toPromise()
    .then((res)=>{
      console.log('token verify then execute');
      if(res=="nouserfound"){
        throw Error;
      }
      return res;
    })
    .catch((error)=>{
        throw error;
    });
  }

  ////////signup

  signupapiCall(url : string,body : any,options :any = '') : Promise<any>{
    
    console.log(url);

    let signReq = this.httpReq.post(url,{'data':body});
    return signReq.toPromise()
    .then((res)=>{
      console.log(res);
      console.log('common service logged');
      return res;
    })
    .catch((error)=>{
        throw error;
    });
  }

  



}


