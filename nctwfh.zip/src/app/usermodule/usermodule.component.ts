import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
import { Router } from '@angular/router'
import { FormBuilder, FormGroup,Validator, Validators } from '@angular/forms';
import {HttpClientModule, HttpClient, HttpRequest, HttpResponse, HttpEventType} from '@angular/common/http';

@Component({
  selector: 'app-usermodule',
  templateUrl: './usermodule.component.html',
  styleUrls: ['./usermodule.component.css']
})
export class UsermoduleComponent implements OnInit {
  public fileGet : FormGroup;
  constructor(public commonservice:CommonService,public router : Router,public builder:FormBuilder,private http: HttpClient) {
      this.fileGet = this.builder.group({
        "file":[null,Validators.required]
      });
   }
   basicUploadSingle(file: File){    
    this.http.post('https://localhost/php/profilepicture/', file)
      .subscribe(event => {  
        console.log('done')
      })
  }
   public firstname : any;
   public lastname: any;
   public email:any;
   public mobile :any;
   public token:any;
   public body : any;

  ngOnInit(): void {
    if(!(localStorage.getItem('token')==null && localStorage.getItem('token') == undefined))
    {
      this.token = localStorage.getItem('token');
      this.body = {"token":this.token};
      let returnOutput = this.commonservice.tokenVerify("http://localhost/php/tokenverifier/",this.body);

      returnOutput.then((res)=>{
         if(res != null && res != undefined)
         {
            
            this.firstname = res.firstname;
            this.lastname = res.lastname;
            this.email = res.email;
            this.mobile = res.mobile;
          }
          else{
            alert("Didn't Get Response");
          }
        })
      .catch((error)=>{
        alert("Token No More Avalible");
        this.router.navigate(['login']);     
      });
    }else
    {
      this.router.navigate(['login']);     
    }
    
  }
  logout(){
    this.commonservice.isLoggedIn = false;
    localStorage.removeItem('token');
    this.router.navigate(['login']);
  }

  fileGets(){
    let file = this.fileGet.value.file;
    console.log(file);
  }

}
